package com.example.conversor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button botao;
    EditText txt;
    TextView resultado;
    double s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botao =findViewById(R.id.btn1);
        txt= findViewById(R.id.txt);
        resultado = findViewById(R.id.res);
    }
    public void OnClick(View v)
    {
        Double ce =Double.parseDouble(txt.getText().toString());
        s=ce*1.8 +32;
        resultado.setText( s + "Fahrenheit");

    }

}